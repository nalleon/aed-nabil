<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="Nabil León Álavarez">
        <title>Class exercise</title>
        <link rel="stylesheet" href="./style/startpage.css">

    </head>
    <body class="antialiased">
        <div class="main-container">
            <h2>Startpage</h2>
                <p>User: <b>{{$newUser->username}}</b></p>

               @csrf
                <form action="{{url('/postMessage')}}" method="POST">
                    <input type="text" id="user" name="user" value="{{$newUser->username}}">
                    <input type="text" id="message" name="message"/>
                    <input type="submit" id="submit" name="submit" value="Send"/>
                </form>



                <div class="messages">
                    <li>
                    </li>

                </div>
        </div>
    </body>

</html>
