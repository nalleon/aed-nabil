<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="Nabil L.A.">
        <title>Tasks</title>
        <link rel="stylesheet" href="./style/tasks.css">

    </head>
    <body class="antialiased">
        <div class="main-container">
            <h2>TASK TO UPDATE</h2>
            <form action="<?php echo e(url('task/update')); ?>" method="POST" id="formTasks">
                <?php echo csrf_field(); ?>
                <label for="subject">Task ID: <?php echo e($auxTask->id); ?></label>
                <br>
                <input type="hidden" name="id" value="<?php echo e($auxTask->id); ?>">
                <input type="text" name="subject" id="subject" placeholder="Task subject" value="<?php echo e($auxTask->subject); ?>" />
                <textarea cols="200" rows="5" name="description" placeholder="Task description" id="description"><?php echo e($auxTask->description); ?></textarea>
            
                <label for="finished">Status:</label><br>
                <div class="status-container">
                    <?php if($auxTask->finished): ?>
                        <input type="radio" value="Open" name="finished" id="finishedOpen"> 
                        <label for="finishedOpen">Open</label>
                        <input type="radio" value="Closed" name="finished" id="finishedClosed" checked> 
                        <label for="finishedClosed">Close</label>
                    <?php else: ?>
                        <input type="radio" value="Open" name="finished" id="finishedOpen" checked> 
                        <label for="finishedOpen">Open</label>
                        <input type="radio" value="Closed" name="finished" id="finishedClosed"> 
                        <label for="finishedClosed">Close</label>
                    <?php endif; ?>
                </div>
            
                <input type="submit" name="submit" id="submit" value="Update">
            </form>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\nabil\repositorios-git\aed-nabil\unit-01\laravel\to-do-file\resources\views/tasks.blade.php ENDPATH**/ ?>