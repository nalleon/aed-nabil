<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="Nabil L.A.">
        <title>To Do</title>
        <link rel="stylesheet" href="./style/startpage.css">

    </head>
    <body class="antialiased">
        <div class="main-container">

            <h2>ALL TASKS</h2>
            <ul>
                <?php $__currentLoopData = $todolist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="./task?id=<?php echo e($task->id); ?>"><?php echo e($task->subject); ?></a>
                        <a href="./task?id=<?php echo e($task->id); ?>"><?php echo e($task->description); ?></a>
                        <a href="./task?id=<?php echo e($task->id); ?>"><?php echo e($task->finished ? 'Finished' : 'Not finished'); ?></a>

                        <form action="<?php echo e(url('task/delete')); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($task->id); ?>">
                            <input type="submit" name="delete" id="delete" value="Delete">
                        </form>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>     

            <form action="<?php echo e(url('task/create')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label for="subject">Task Subject:</label>
                <input type="text" name="subject" id="subject" placeholder="Task subject" />
                <br>
                <label for="description">Task Description:</label>
                <textarea cols="50" rows="5" name="description" id="description" placeholder="Task description"></textarea>
                <br>
                <label for="finished">Status:</label><br>
                <div class="status-container">
                    <input type="radio" value="Open" name="finished" id="finishedOpen" checked> 
                    <label for="finishedOpen">Open</label><br>
                    <input type="radio" value="Closed" name="finished" id="finishedClosed"> 
                    <label for="finishedClosed">Closed</label><br>
                </div>                
                <br>
                <input type="submit" name="create" value="Create">
            </form>
        </div>   
    </body>
</html>
<?php /**PATH C:\Users\nabil\repositorios-git\aed-nabil\unit-01\laravel\to-do-laravel\resources\views/startpage.blade.php ENDPATH**/ ?>