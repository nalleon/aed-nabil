<?php
echo "<p style='background: pink'>Soy Nabil. Este es mi primer script php";
echo "</p>";

phpinfo();

?>