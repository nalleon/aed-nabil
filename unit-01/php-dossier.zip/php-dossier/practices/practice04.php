<?php
declare(strict_types=1);
?>
<!DOCTYPE html>
<html>
    <head>
<meta charset="UTF-8">
<title></title>
</head>
<body>
<?php
function fun( int $a, int $b) : int{
$a = "o";
//return $a;
return $b ;
}
//print fun(1,2);
print fun("e",3);
echo "</p>"
?>
</body>
</html>