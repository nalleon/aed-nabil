<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practice13</title>
    <meta name="author" content="Nabil L.A.">
</head>
<body>
<?php
    $variable = 'dato';
    $dato = 5;
    echo ${$variable}.'<br>';
?>
</body>
</html>