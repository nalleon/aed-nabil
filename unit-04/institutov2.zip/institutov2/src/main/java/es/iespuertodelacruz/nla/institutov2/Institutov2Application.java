package es.iespuertodelacruz.nla.institutov2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Institutov2Application {

	public static void main(String[] args) {
		SpringApplication.run(Institutov2Application.class, args);
	}

}
