package es.iespuertodelacruz.nla.institutov2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Institutov2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
